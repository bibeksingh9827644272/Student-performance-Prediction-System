import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';
import { parse } from 'csv-parse/sync';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('DATABASE_URL environment variable is not set');
  process.exit(1);
}

async function importData() {
  let connection;
  try {
    // Parse the database URL
    const url = new URL(DATABASE_URL);
    const config = {
      host: url.hostname,
      port: url.port || 3306,
      user: url.username,
      password: url.password,
      database: url.pathname.slice(1),
      ssl: { rejectUnauthorized: false },
    };

    connection = await mysql.createConnection(config);
    console.log('Connected to database');

    // Read CSV file
    const csvPath = path.join(__dirname, '../../upload/Dataset.csv');
    const fileContent = fs.readFileSync(csvPath, 'utf-8');
    
    const records = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
    });

    console.log(`Found ${records.length} records to import`);

    // Prepare insert statements
    let inserted = 0;
    for (const record of records) {
      // Handle BOM character in first column name
      const rollNoKey = Object.keys(record)[0];
      const student = {
        rollNo: record[rollNoKey],
        studentName: record['Student_Name'] || record['Student_Name'],
        gender: record['Gender'],
        department: record['Department'],
        batch: record['Batch'],
        tenthMarks: parseInt(record['10th Marks in percent']),
        tenthAttendance: parseInt(record['Attendence of 10th']),
        twelfthMarks: parseInt(record['12th Marks in percent']),
        twelfthAttendance: parseInt(record['Attendence of 12th']),
        cgpa1stSem: parseInt(record['CGPA of 1st Sem']),
        attendance1stSem: parseInt(record['Attendence of 1st Sem']),
        assignment1stSem: parseInt(record['Assignment Marks of 1st Sem']),
        sessional1stSem: parseInt(record['Sessional Marks of 1st Sem']),
        internal1stSem: parseInt(record['Internal Marks of 1st Sem']),
        cgpa2ndSem: parseInt(record['CGPA of 2nd Sem']),
        attendance2ndSem: parseInt(record['Attendence of 2nd Sem']),
        assignment2ndSem: parseInt(record['Assignment Marks of 2nd Sem']),
        sessional2ndSem: parseInt(record['Sessional Marks of 2nd Sem']),
        internal2ndSem: parseInt(record['Internal Marks of 2rnd Sem']),
        cgpa3rdSem: parseInt(record['CGPA of 3rd Sem']),
        attendance3rdSem: parseInt(record['Attendence of 3rd Sem']),
        assignment3rdSem: parseInt(record['Assignment Marks of 3rd Sem']),
        sessional3rdSem: parseInt(record['Sessional Marks of 3rd Sem']),
        internal3rdSem: parseInt(record['Internal Marks of 3rd Sem']),
        cgpa4thSem: parseInt(record['CGPA of 4th Sem']),
        attendance4thSem: parseInt(record['Attendence of 4th Sem']),
        assignment4thSem: parseInt(record['Assignment Marks of 4th Sem']),
        sessional4thSem: parseInt(record['Sessional Marks of 4th Sem']),
        internal4thSem: parseInt(record['Internal Marks of 4th Sem']),
      };

      const columns = Object.keys(student);
      const values = Object.values(student).map(v => v === undefined ? null : v);
      const placeholders = columns.map(() => '?').join(',');
      const query = `INSERT INTO students (${columns.join(',')}) VALUES (${placeholders})`;
      await connection.execute(query, values);
      inserted++;

      if (inserted % 100 === 0) {
        console.log(`Imported ${inserted} records...`);
      }
    }

    console.log(`Successfully imported ${inserted} student records`);
    await connection.end();
  } catch (error) {
    console.error('Error importing data:', error);
    process.exit(1);
  }
}

importData();
