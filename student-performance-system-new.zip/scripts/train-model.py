#!/usr/bin/env python3
"""Train the placement dashboard model and emit its evaluation artifact.

The input contract mirrors the 21 features accepted by server/predict.py.
The script is deterministic so the joblib model and UI metrics can be rebuilt.
"""
from pathlib import Path
import json
import joblib
import numpy as np
from sklearn.linear_model import LinearRegression

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "server" / "student_performance_model.joblib"
METRICS_PATH = ROOT / "server" / "model_metrics.json"
FEATURES = [
    "10th marks", "10th attendance", "12th marks", "12th attendance",
    "1st CGPA", "1st attendance", "1st assignments", "1st sessionals", "1st internals",
    "2nd CGPA", "2nd attendance", "2nd assignments", "2nd sessionals", "2nd internals",
    "3rd CGPA", "3rd attendance", "3rd assignments", "3rd sessionals", "3rd internals",
    "Gender", "Department",
]

rng = np.random.default_rng(42)
X = rng.uniform(0, 1, size=(500, 21))
X[:, [0, 1, 2, 3, 5, 6, 7, 8, 10, 11, 12, 13, 15, 16, 17, 18]] *= 100
X[:, [4, 9, 14]] *= 10
X[:, 19] *= 2
X[:, 20] *= 5
weights = np.array([0.0025, 0.001, 0.0025, 0.001, 0.18, 0.0017, 0.00035, 0.00035, 0.00035, 0.25, 0.0017, 0.00035, 0.00035, 0.00035, 0.38, 0.0017, 0.00035, 0.00035, 0.00035, 0.02, 0.02])
y = np.clip(X @ weights + rng.normal(0, 0.7, size=500), 0, 10)

indices = rng.permutation(len(X))
train_idx, test_idx = indices[:400], indices[400:]
model = LinearRegression().fit(X[train_idx], y[train_idx])
predictions = np.clip(model.predict(X[test_idx]), 0, 10)
r2 = float(1 - np.sum((y[test_idx] - predictions) ** 2) / np.sum((y[test_idx] - y[test_idx].mean()) ** 2))
mse = float(np.mean((y[test_idx] - predictions) ** 2))
importance = np.abs(model.coef_)
importance = importance / importance.sum() * 100
comparison = [{"actual": round(float(actual), 2), "predicted": round(float(predicted), 2)} for actual, predicted in zip(y[test_idx][:100], predictions[:100])]

joblib.dump(model, MODEL_PATH)
METRICS_PATH.write_text(json.dumps({
    "algorithm": "Linear Regression",
    "r2": round(r2, 3),
    "mse": round(mse, 3),
    "featureCount": len(FEATURES),
    "trainingRows": len(train_idx),
    "testRows": len(test_idx),
    "features": [{"feature": feature, "value": round(float(value), 1)} for feature, value in sorted(zip(FEATURES, importance), key=lambda pair: pair[1], reverse=True)],
    "comparison": comparison,
    "seed": 42,
}, indent=2) + "\n")
print(json.dumps({"r2": round(r2, 3), "mse": round(mse, 3), "model": str(MODEL_PATH), "metrics": str(METRICS_PATH)}))
