import { useMemo, useState } from "react";
import { ArrowDownUp, ChevronLeft, ChevronRight, Search, SlidersHorizontal } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";

const n = (value: unknown) => Number(value ?? 0);

export default function DatasetExplorer() {
  const { data: students = [], isLoading } = trpc.students.all.useQuery();
  const [query, setQuery] = useState("");
  const [department, setDepartment] = useState("all");
  const [batch, setBatch] = useState("all");
  const [gender, setGender] = useState("all");
  const [sort, setSort] = useState<keyof (typeof students)[number]>("rollNo");
  const [page, setPage] = useState(1);
  const pageSize = 12;
  const departments = useMemo(() => Array.from(new Set(students.map(s => s.department))), [students]);
  const batches = useMemo(() => Array.from(new Set(students.map(s => s.batch))), [students]);
  const genders = useMemo(() => Array.from(new Set(students.map(s => s.gender))), [students]);
  const filtered = useMemo(() => {
    const lowered = query.toLowerCase().trim();
    return [...students].filter(student => {
      const matchesQuery = !lowered || student.studentName.toLowerCase().includes(lowered) || student.rollNo.toLowerCase().includes(lowered);
      return matchesQuery && (department === "all" || student.department === department) && (batch === "all" || student.batch === batch) && (gender === "all" || student.gender === gender);
    }).sort((a, b) => {
      const av = sort.toLowerCase().includes("cgpa") ? n(a[sort]) : String(a[sort] ?? "");
      const bv = sort.toLowerCase().includes("cgpa") ? n(b[sort]) : String(b[sort] ?? "");
      return av < bv ? -1 : av > bv ? 1 : 0;
    });
  }, [students, query, department, batch, gender, sort]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const rows = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);

  const reset = () => { setQuery(""); setDepartment("all"); setBatch("all"); setGender("all"); setPage(1); };
  return <DashboardLayout><div className="mx-auto max-w-[1440px] space-y-6">
    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="text-sm font-semibold text-[#27a78f]">Source of truth</p><h2 className="mt-1 font-display text-3xl font-bold tracking-tight text-[#10213d]">Dataset explorer</h2><p className="mt-2 max-w-2xl text-sm text-[#8294aa]">Search across the 500 student records powering the CGPA prediction system.</p></div><Badge className="w-fit border-0 bg-[#e4f8f3] px-3 py-1.5 text-[#087e6c]">{filtered.length} matching records</Badge></div>
    <Card className="border-0 bg-white shadow-[0_10px_35px_rgba(20,54,95,0.07)]"><CardContent className="p-4"><div className="flex flex-col gap-3 xl:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#9aacbe]" /><Input value={query} onChange={event => { setQuery(event.target.value); setPage(1); }} placeholder="Search by student name or roll number" className="h-11 border-[#dbe5f0] pl-10 text-sm shadow-none focus-visible:ring-[#27c7a5]" /></div><div className="flex flex-wrap gap-2"><Select value={department} onValueChange={value => { setDepartment(value); setPage(1); }}><SelectTrigger className="h-11 w-[180px] border-[#dbe5f0] text-xs"><SelectValue placeholder="Department" /></SelectTrigger><SelectContent><SelectItem value="all">All departments</SelectItem>{departments.map(value => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select><Select value={batch} onValueChange={value => { setBatch(value); setPage(1); }}><SelectTrigger className="h-11 w-[150px] border-[#dbe5f0] text-xs"><SelectValue placeholder="Batch" /></SelectTrigger><SelectContent><SelectItem value="all">All batches</SelectItem>{batches.map(value => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select><Select value={gender} onValueChange={value => { setGender(value); setPage(1); }}><SelectTrigger className="h-11 w-[130px] border-[#dbe5f0] text-xs"><SelectValue placeholder="Gender" /></SelectTrigger><SelectContent><SelectItem value="all">All genders</SelectItem>{genders.map(value => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select><Button variant="outline" onClick={reset} className="h-11 border-[#dbe5f0] text-[#536d8b]"><SlidersHorizontal className="mr-2 h-4 w-4" />Reset</Button></div></div></CardContent></Card>
    <Card className="overflow-hidden border-0 bg-white shadow-[0_10px_35px_rgba(20,54,95,0.07)]"><div className="overflow-x-auto"><table className="w-full min-w-[920px] text-left"><thead className="bg-[#f7f9fc] text-[10px] uppercase tracking-[0.14em] text-[#8798ad]"><tr><th className="px-5 py-4 font-bold">Student</th><th className="px-4 py-4 font-bold">Department</th><th className="px-4 py-4 font-bold">Batch</th><th className="px-4 py-4 font-bold">10th / 12th</th><th className="px-4 py-4 font-bold">1st CGPA</th><th className="px-4 py-4 font-bold">2nd CGPA</th><th className="px-4 py-4 font-bold">3rd CGPA</th><th className="px-4 py-4 font-bold">4th CGPA</th><th className="px-5 py-4 text-right"><button className="inline-flex items-center gap-1 font-bold" onClick={() => setSort("cgpa4thSem")}><ArrowDownUp className="h-3 w-3" />Sort</button></th></tr></thead><tbody className="divide-y divide-[#edf2f7]">{isLoading ? <tr><td colSpan={9} className="px-5 py-14 text-center text-sm text-[#8294aa]">Loading student records…</td></tr> : rows.length ? rows.map(student => <tr key={student.id} className="transition hover:bg-[#f8fbfd]"><td className="px-5 py-3.5"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e9f0ff] text-xs font-bold text-[#3c76df]">{student.studentName.split(" ").map(part => part[0]).slice(0, 2).join("")}</div><div><p className="text-sm font-semibold text-[#183251]">{student.studentName}</p><p className="text-xs text-[#8a9bae]">#{student.rollNo} · {student.gender}</p></div></div></td><td className="px-4 py-3.5 text-sm text-[#536d8b]">{student.department}</td><td className="px-4 py-3.5 text-sm text-[#536d8b]">{student.batch}</td><td className="px-4 py-3.5 text-sm font-semibold text-[#385572]">{student.tenthMarks}% <span className="text-[#b2bfcc]">/</span> {student.twelfthMarks}%</td><td className="px-4 py-3.5 text-sm text-[#536d8b]">{n(student.cgpa1stSem).toFixed(2)}</td><td className="px-4 py-3.5 text-sm text-[#536d8b]">{n(student.cgpa2ndSem).toFixed(2)}</td><td className="px-4 py-3.5 text-sm text-[#536d8b]">{n(student.cgpa3rdSem).toFixed(2)}</td><td className="px-4 py-3.5"><span className="rounded-lg bg-[#e4f8f3] px-2.5 py-1.5 text-sm font-bold text-[#087e6c]">{n(student.cgpa4thSem).toFixed(2)}</span></td><td className="px-5 py-3.5 text-right text-xs font-semibold text-[#9aacbe]">{student.attendance4thSem}% att.</td></tr>) : <tr><td colSpan={9} className="px-5 py-14 text-center text-sm text-[#8294aa]">No records match these filters.</td></tr>}</tbody></table></div><div className="flex items-center justify-between border-t border-[#edf2f7] px-5 py-4"><p className="text-xs text-[#8294aa]">Showing {rows.length ? (safePage - 1) * pageSize + 1 : 0}–{Math.min(safePage * pageSize, filtered.length)} of {filtered.length}</p><div className="flex items-center gap-2"><Button variant="outline" size="sm" disabled={safePage <= 1} className="border-[#dbe5f0]" onClick={() => setPage(value => Math.max(1, value - 1))}><ChevronLeft className="h-4 w-4" />Previous</Button><span className="min-w-16 text-center text-xs font-bold text-[#536d8b]">{safePage} / {totalPages}</span><Button variant="outline" size="sm" disabled={safePage >= totalPages} className="border-[#dbe5f0]" onClick={() => setPage(value => Math.min(totalPages, value + 1))}>Next<ChevronRight className="h-4 w-4" /></Button></div></div></Card>
  </div></DashboardLayout>;
}
