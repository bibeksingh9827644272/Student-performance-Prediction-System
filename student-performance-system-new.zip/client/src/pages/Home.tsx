import { Link } from "wouter";
import { ArrowUpRight, BarChart3, BrainCircuit, GraduationCap, Users } from "lucide-react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";

const colors = ["#27c7a5", "#4d8df7", "#f2b35d", "#8b78e6", "#ef7e8a"];
const number = (value: unknown) => Number(value ?? 0);

function StatCard({ icon: Icon, label, value, helper, tone }: { icon: typeof Users; label: string; value: string; helper: string; tone: string }) {
  return <Card className="border-0 bg-white shadow-[0_10px_35px_rgba(20,54,95,0.07)]"><CardContent className="p-5"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#8294aa]">{label}</p><p className="mt-3 font-display text-3xl font-bold tracking-tight text-[#10213d]">{value}</p><p className="mt-2 text-xs text-[#7890a9]">{helper}</p></div><span className={`flex h-11 w-11 items-center justify-center rounded-2xl ${tone}`}><Icon className="h-5 w-5" /></span></div></CardContent></Card>;
}

export default function Home() {
  const { data: stats, isLoading } = trpc.students.getStats.useQuery();
  const { data: analytics } = trpc.students.getAnalytics.useQuery();
  const { data: model } = trpc.model.getMetrics.useQuery();
  const departments = stats?.departments ?? [];
  const total = number(stats?.totalStudents);
  const avg = number(stats?.avgCgpa);

  return <DashboardLayout>
    <div className="mx-auto max-w-[1440px] space-y-7">
      <section className="relative overflow-hidden rounded-[28px] bg-[#0b2448] px-6 py-8 text-white shadow-xl shadow-[#0b2448]/15 sm:px-9 sm:py-10">
        <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full border-[34px] border-[#27c7a5]/20" /><div className="absolute -bottom-32 right-28 h-64 w-64 rounded-full border-[24px] border-[#4d8df7]/15" />
        <div className="relative max-w-2xl"><p className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-[#8de8d4]">Placement readiness · 2024 cohort</p><h2 className="font-display text-3xl font-bold leading-tight tracking-tight sm:text-4xl">Turn academic signals into your next best move.</h2><p className="mt-4 max-w-xl text-sm leading-6 text-blue-100/75">Monitor student momentum, explore the 500-record dataset, and forecast 4th-semester CGPA with a transparent 21-feature model.</p><div className="mt-7 flex flex-wrap gap-3"><Link href="/prediction" className="inline-flex items-center gap-2 rounded-xl bg-[#27c7a5] px-4 py-2.5 text-sm font-bold text-[#06243c] transition-transform hover:-translate-y-0.5">Run a prediction <ArrowUpRight className="h-4 w-4" /></Link><Link href="/analytics" className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-4 py-2.5 text-sm font-semibold text-white hover:bg-white/10">Open analytics</Link></div></div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon={Users} label="Students tracked" value={isLoading ? "—" : total.toLocaleString()} helper="Across 5 departments" tone="bg-[#e3f8f3] text-[#078875]" />
        <StatCard icon={GraduationCap} label="Average 4th CGPA" value={isLoading ? "—" : avg.toFixed(2)} helper="Current outcome baseline" tone="bg-[#e9f0ff] text-[#3b73dd]" />
        <StatCard icon={BarChart3} label="Top department" value={departments[0]?.name?.replace("Information Technology", "IT") ?? "—"} helper={departments[0] ? `${number(departments[0].avgCgpa).toFixed(2)} avg CGPA` : "Awaiting data"} tone="bg-[#fff1dd] text-[#d88a23]" />
        <StatCard icon={BrainCircuit} label="Model R²" value={model ? model.r2.toFixed(2) : "—"} helper="Linear Regression · 21 features" tone="bg-[#f1eaff] text-[#795bca]" />
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.25fr_1fr]">
        <Card className="border-0 bg-white shadow-[0_10px_35px_rgba(20,54,95,0.07)]"><CardHeader className="flex-row items-start justify-between space-y-0"><div><CardTitle className="font-display text-lg text-[#10213d]">Department pulse</CardTitle><p className="mt-1 text-sm text-[#8294aa]">Average 4th-semester CGPA by department</p></div><Link href="/analytics" className="text-xs font-bold text-[#197fbe] hover:underline">View detail</Link></CardHeader><CardContent><div className="h-[260px] w-full">{departments.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={departments} margin={{ top: 12, right: 10, left: -18, bottom: 0 }}><XAxis dataKey="name" tick={{ fill: "#8294aa", fontSize: 11 }} tickFormatter={(name) => String(name).replace("Information Technology", "IT")} axisLine={false} tickLine={false} /><YAxis domain={[0, 10]} tick={{ fill: "#9aaabd", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip cursor={{ fill: "#f4f7fb" }} formatter={(value: number) => [number(value).toFixed(2), "Avg CGPA"]} /><Bar dataKey="avgCgpa" radius={[7, 7, 0, 0]}>{departments.map((_, index) => <Cell key={index} fill={colors[index % colors.length]} />)}</Bar></BarChart></ResponsiveContainer> : <div className="flex h-full items-center justify-center text-sm text-[#8294aa]">No department data yet.</div>}</div></CardContent></Card>
        <Card className="border-0 bg-white shadow-[0_10px_35px_rgba(20,54,95,0.07)]"><CardHeader><CardTitle className="font-display text-lg text-[#10213d]">Semester trajectory</CardTitle><p className="mt-1 text-sm text-[#8294aa]">Cohort average across the first four semesters</p></CardHeader><CardContent><div className="space-y-4">{(analytics?.semesterTrends ?? []).map((item, index) => <div key={item.semester}><div className="mb-2 flex items-center justify-between text-sm"><span className="font-semibold text-[#48617f]">{item.semester} semester</span><span className="font-display font-bold text-[#10213d]">{number(item.avgCgpa).toFixed(2)}</span></div><div className="h-2 overflow-hidden rounded-full bg-[#edf2f7]"><div className="h-full rounded-full" style={{ width: `${Math.min(100, number(item.avgCgpa) * 10)}%`, background: colors[index] }} /></div></div>)}{!analytics?.semesterTrends?.length && <p className="text-sm text-[#8294aa]">Loading cohort trend…</p>}</div></CardContent></Card>
      </section>

      <section className="grid gap-4 md:grid-cols-3"><Link href="/dataset" className="group rounded-2xl border border-[#dce7f1] bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#27a78f]">01 · Explore</p><h3 className="mt-3 font-display text-lg font-bold text-[#10213d]">Browse every student signal</h3><p className="mt-2 text-sm leading-5 text-[#8294aa]">Filter, sort, and inspect the source records used by the dashboard.</p><ArrowUpRight className="mt-4 h-5 w-5 text-[#27a78f] transition group-hover:translate-x-1" /></Link><Link href="/students" className="group rounded-2xl border border-[#dce7f1] bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#4d8df7]">02 · Understand</p><h3 className="mt-3 font-display text-lg font-bold text-[#10213d]">Open a student profile</h3><p className="mt-2 text-sm leading-5 text-[#8294aa]">Compare semester momentum, attendance, and assessment performance.</p><ArrowUpRight className="mt-4 h-5 w-5 text-[#4d8df7] transition group-hover:translate-x-1" /></Link><Link href="/metrics" className="group rounded-2xl border border-[#dce7f1] bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#8b78e6]">03 · Trust</p><h3 className="mt-3 font-display text-lg font-bold text-[#10213d]">Review model quality</h3><p className="mt-2 text-sm leading-5 text-[#8294aa]">See validation metrics and which features influence the forecast most.</p><ArrowUpRight className="mt-4 h-5 w-5 text-[#8b78e6] transition group-hover:translate-x-1" /></Link></section>
    </div>
  </DashboardLayout>;
}
