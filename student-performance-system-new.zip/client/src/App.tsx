import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Analytics from "./pages/Analytics";
import DatasetExplorer from "./pages/DatasetExplorer";
import Home from "./pages/Home";
import ModelMetrics from "./pages/ModelMetrics";
import Prediction from "./pages/Prediction";
import StudentProfiles from "./pages/StudentProfiles";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/dataset" component={DatasetExplorer} />
    <Route path="/students" component={StudentProfiles} />
    <Route path="/prediction" component={Prediction} />
    <Route path="/analytics" component={Analytics} />
    <Route path="/metrics" component={ModelMetrics} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
