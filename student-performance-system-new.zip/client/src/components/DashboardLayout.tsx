import { Menu, Sparkles, X } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

const menuItems = [
  { label: "Home", path: "/", icon: "⌂" },
  { label: "Dataset Explorer", path: "/dataset", icon: "▤" },
  { label: "Student Profiles", path: "/students", icon: "◎" },
  { label: "CGPA Prediction", path: "/prediction", icon: "✦" },
  { label: "Analytics", path: "/analytics", icon: "◒" },
  { label: "Model Metrics", path: "/metrics", icon: "▥" },
];

const pageTitles: Record<string, string> = Object.fromEntries(menuItems.map(item => [item.path, item.label]));

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const title = pageTitles[location] ?? "Academic overview";

  return (
    <div className="min-h-screen bg-[#f4f7fb] text-[#10213d]">
      <aside className={`fixed inset-y-0 left-0 z-50 flex w-[272px] flex-col bg-[#081a38] px-5 py-6 text-white shadow-2xl shadow-[#081a38]/20 transition-transform duration-200 lg:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="mb-10 flex items-start justify-between">
          <Link href="/" onClick={() => setMobileOpen(false)} className="group flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#27c7a5] text-xl font-bold text-[#06243c] shadow-lg shadow-[#27c7a5]/20">A</span>
            <span>
              <span className="block font-display text-[17px] font-bold tracking-tight">Academic Atlas</span>
              <span className="mt-0.5 block text-[11px] font-medium uppercase tracking-[0.18em] text-blue-200/70">Placement command center</span>
            </span>
          </Link>
          <button aria-label="Close navigation" className="rounded-lg p-1 text-blue-100/70 hover:bg-white/10 lg:hidden" onClick={() => setMobileOpen(false)}><X className="h-5 w-5" /></button>
        </div>

        <div className="mb-4 px-3 text-[10px] font-bold uppercase tracking-[0.22em] text-blue-200/50">Workspace</div>
        <nav className="space-y-1.5" aria-label="Primary navigation">
          {menuItems.map(item => {
            const active = location === item.path || (item.path !== "/" && location.startsWith(item.path));
            return (
              <Link key={item.path} href={item.path} onClick={() => setMobileOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition-all ${active ? "bg-white text-[#09203f] shadow-lg shadow-black/10" : "text-blue-100/75 hover:bg-white/10 hover:text-white"}`}>
                <span className={`flex h-7 w-7 items-center justify-center rounded-lg text-base ${active ? "bg-[#d9f8f1] text-[#087d6b]" : "bg-white/10 text-blue-100/80 group-hover:bg-white/15"}`}>{item.icon}</span>
                <span>{item.label}</span>
                {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#27c7a5]" />}
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto rounded-2xl border border-white/10 bg-white/[0.06] p-4">
          <div className="mb-3 flex items-center gap-2 text-[#8de8d4]"><Sparkles className="h-4 w-4" /><span className="text-xs font-semibold">Model ready</span></div>
          <p className="text-xs leading-5 text-blue-100/65">21 academic signals are available for 4th-semester CGPA forecasting.</p>
        </div>
      </aside>

      {mobileOpen && <button aria-label="Close navigation overlay" className="fixed inset-0 z-40 bg-[#06162f]/60 lg:hidden" onClick={() => setMobileOpen(false)} />}
      <div className="lg:pl-[272px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-[#dbe5f0] bg-white/90 px-5 backdrop-blur-xl sm:px-8">
          <div className="flex items-center gap-3">
            <button aria-label="Open navigation" className="rounded-xl border border-[#dbe5f0] p-2 text-[#335172] hover:bg-[#f0f5fa] lg:hidden" onClick={() => setMobileOpen(true)}><Menu className="h-5 w-5" /></button>
            <div><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8193aa]">Student intelligence</p><h1 className="font-display text-xl font-bold tracking-tight text-[#10213d] sm:text-2xl">{title}</h1></div>
          </div>
          <div className="hidden items-center gap-3 sm:flex"><span className="h-2 w-2 rounded-full bg-[#27c7a5] shadow-[0_0_0_4px_#dff9f2]" /><span className="text-xs font-semibold text-[#617690]">Live dataset · 500 students</span></div>
        </header>
        <main className="min-h-[calc(100vh-76px)] px-5 py-7 sm:px-8 lg:px-10">{children}</main>
      </div>
    </div>
  );
}
