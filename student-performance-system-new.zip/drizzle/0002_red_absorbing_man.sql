ALTER TABLE `predictions` MODIFY COLUMN `predictedCgpa` decimal(4,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `predictions` MODIFY COLUMN `actualCgpa` decimal(4,2);--> statement-breakpoint
ALTER TABLE `students` MODIFY COLUMN `cgpa1stSem` decimal(4,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `students` MODIFY COLUMN `cgpa2ndSem` decimal(4,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `students` MODIFY COLUMN `cgpa3rdSem` decimal(4,2) NOT NULL;--> statement-breakpoint
ALTER TABLE `students` MODIFY COLUMN `cgpa4thSem` decimal(4,2) NOT NULL;