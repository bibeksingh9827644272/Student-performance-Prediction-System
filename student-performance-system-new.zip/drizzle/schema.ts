import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  rollNo: varchar("rollNo", { length: 20 }).notNull().unique(),
  studentName: varchar("studentName", { length: 255 }).notNull(),
  gender: varchar("gender", { length: 20 }).notNull(),
  department: varchar("department", { length: 100 }).notNull(),
  batch: varchar("batch", { length: 20 }).notNull(),
  
  // 10th and 12th marks
  tenthMarks: int("tenthMarks").notNull(),
  tenthAttendance: int("tenthAttendance").notNull(),
  twelfthMarks: int("twelfthMarks").notNull(),
  twelfthAttendance: int("twelfthAttendance").notNull(),
  
  // 1st Semester
  cgpa1stSem: decimal("cgpa1stSem", { precision: 4, scale: 2 }).notNull(),
  attendance1stSem: int("attendance1stSem").notNull(),
  assignment1stSem: int("assignment1stSem").notNull(),
  sessional1stSem: int("sessional1stSem").notNull(),
  internal1stSem: int("internal1stSem").notNull(),
  
  // 2nd Semester
  cgpa2ndSem: decimal("cgpa2ndSem", { precision: 4, scale: 2 }).notNull(),
  attendance2ndSem: int("attendance2ndSem").notNull(),
  assignment2ndSem: int("assignment2ndSem").notNull(),
  sessional2ndSem: int("sessional2ndSem").notNull(),
  internal2ndSem: int("internal2ndSem").notNull(),
  
  // 3rd Semester
  cgpa3rdSem: decimal("cgpa3rdSem", { precision: 4, scale: 2 }).notNull(),
  attendance3rdSem: int("attendance3rdSem").notNull(),
  assignment3rdSem: int("assignment3rdSem").notNull(),
  sessional3rdSem: int("sessional3rdSem").notNull(),
  internal3rdSem: int("internal3rdSem").notNull(),
  
  // 4th Semester (target)
  cgpa4thSem: decimal("cgpa4thSem", { precision: 4, scale: 2 }).notNull(),
  attendance4thSem: int("attendance4thSem").notNull(),
  assignment4thSem: int("assignment4thSem").notNull(),
  sessional4thSem: int("sessional4thSem").notNull(),
  internal4thSem: int("internal4thSem").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

export const predictions = mysqlTable("predictions", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id),
  predictedCgpa: decimal("predictedCgpa", { precision: 4, scale: 2 }).notNull(),
  actualCgpa: decimal("actualCgpa", { precision: 4, scale: 2 }),
  inputFeatures: text("inputFeatures").notNull(), // JSON string
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;
