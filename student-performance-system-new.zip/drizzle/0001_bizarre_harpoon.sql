CREATE TABLE `predictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentId` int NOT NULL,
	`predictedCgpa` int NOT NULL,
	`actualCgpa` int,
	`inputFeatures` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `predictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`rollNo` varchar(20) NOT NULL,
	`studentName` varchar(255) NOT NULL,
	`gender` varchar(20) NOT NULL,
	`department` varchar(100) NOT NULL,
	`batch` varchar(20) NOT NULL,
	`tenthMarks` int NOT NULL,
	`tenthAttendance` int NOT NULL,
	`twelfthMarks` int NOT NULL,
	`twelfthAttendance` int NOT NULL,
	`cgpa1stSem` int NOT NULL,
	`attendance1stSem` int NOT NULL,
	`assignment1stSem` int NOT NULL,
	`sessional1stSem` int NOT NULL,
	`internal1stSem` int NOT NULL,
	`cgpa2ndSem` int NOT NULL,
	`attendance2ndSem` int NOT NULL,
	`assignment2ndSem` int NOT NULL,
	`sessional2ndSem` int NOT NULL,
	`internal2ndSem` int NOT NULL,
	`cgpa3rdSem` int NOT NULL,
	`attendance3rdSem` int NOT NULL,
	`assignment3rdSem` int NOT NULL,
	`sessional3rdSem` int NOT NULL,
	`internal3rdSem` int NOT NULL,
	`cgpa4thSem` int NOT NULL,
	`attendance4thSem` int NOT NULL,
	`assignment4thSem` int NOT NULL,
	`sessional4thSem` int NOT NULL,
	`internal4thSem` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `students_id` PRIMARY KEY(`id`),
	CONSTRAINT `students_rollNo_unique` UNIQUE(`rollNo`)
);
--> statement-breakpoint
ALTER TABLE `predictions` ADD CONSTRAINT `predictions_studentId_students_id_fk` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE no action ON UPDATE no action;