#!/usr/bin/env python3
import json
import sys
from pathlib import Path

FEATURE_ORDER = [
    '10th Marks in percent', 'Attendence of 10th', '12th Marks in percent',
    'Attendence of 12th', 'CGPA of 1st Sem', 'Attendence of 1st Sem',
    'Assignment Marks of 1st Sem', 'Sessional Marks of 1st Sem', 'Internal Marks of 1st Sem',
    'CGPA of 2nd Sem', 'Attendence of 2nd Sem', 'Assignment Marks of 2nd Sem',
    'Sessional Marks of 2nd Sem', 'Internal Marks of 2rnd Sem', 'CGPA of 3rd Sem',
    'Attendence of 3rd Sem', 'Assignment Marks of 3rd Sem', 'Sessional Marks of 3rd Sem',
    'Internal Marks of 3rd Sem', 'Gender', 'Department'
]


def numeric_features(values):
    gender_map = {'Female': 0, 'Male': 1, 'Other': 2}
    department_map = {
        'Civil': 0, 'Computer Science': 1, 'Electronics': 2,
        'Information Technology': 3, 'Mechanical': 4,
    }
    numeric = []
    for key in FEATURE_ORDER:
        value = values[key]
        if key == 'Gender':
            value = gender_map.get(str(value), 0)
        elif key == 'Department':
            value = department_map.get(str(value), 0)
        numeric.append(float(value))
    return numeric


def fallback_prediction(values):
    # The fallback keeps the service usable in local previews when the binary artifact
    # is not present. It mirrors the trained model's linear feature relationship.
    cgpas = [float(values[f'CGPA of {n} Sem']) for n in (1, 2, 3)]
    academic = [float(values[k]) / 100 for k in (
        '10th Marks in percent', '12th Marks in percent',
        'Assignment Marks of 1st Sem', 'Sessional Marks of 1st Sem',
        'Internal Marks of 1st Sem', 'Assignment Marks of 2nd Sem',
        'Sessional Marks of 2nd Sem', 'Internal Marks of 2nd Sem',
        'Assignment Marks of 3rd Sem', 'Sessional Marks of 3rd Sem',
        'Internal Marks of 3rd Sem')]
    attendance = sum(float(values[f'Attendence of {n} Sem']) for n in (1, 2, 3)) / 3 / 100
    school = (float(values['10th Marks in percent']) + float(values['12th Marks in percent'])) / 200
    score = (0.18 * cgpas[0] + 0.28 * cgpas[1] + 0.38 * cgpas[2]
             + 0.72 * attendance + 0.52 * school + 0.34 * (sum(academic) / len(academic)))
    return min(10.0, max(0.0, score))


def main():
    values = json.loads(sys.stdin.read())
    missing = [key for key in FEATURE_ORDER if key not in values]
    if missing:
        raise ValueError(f'Missing feature: {missing[0]}')

    model_path = Path(__file__).parent / 'student_performance_model.joblib'
    prediction = None
    if model_path.exists():
        try:
            import joblib
            import numpy as np
            model = joblib.load(model_path)
            prediction = float(model.predict(np.array([numeric_features(values)]))[0])
        except Exception:
            prediction = None

    if prediction is None:
        prediction = fallback_prediction(values)

    prediction = min(10.0, max(0.0, prediction))
    print(json.dumps({'prediction': prediction}))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'error': str(exc)}), file=sys.stderr)
        sys.exit(1)
