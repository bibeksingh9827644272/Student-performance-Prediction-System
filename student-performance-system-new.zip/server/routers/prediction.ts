import { z } from "zod";
import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { publicProcedure, router } from "../_core/trpc";
import { getDb, getStudentById } from "../db";
import { predictions } from "../../drizzle/schema";

const featureSchema = z.object({
  tenthMarks: z.number().min(0).max(100),
  tenthAttendance: z.number().min(0).max(100),
  twelfthMarks: z.number().min(0).max(100),
  twelfthAttendance: z.number().min(0).max(100),
  cgpa1stSem: z.number().min(0).max(10),
  attendance1stSem: z.number().min(0).max(100),
  assignment1stSem: z.number().min(0).max(100),
  sessional1stSem: z.number().min(0).max(100),
  internal1stSem: z.number().min(0).max(100),
  cgpa2ndSem: z.number().min(0).max(10),
  attendance2ndSem: z.number().min(0).max(100),
  assignment2ndSem: z.number().min(0).max(100),
  sessional2ndSem: z.number().min(0).max(100),
  internal2ndSem: z.number().min(0).max(100),
  cgpa3rdSem: z.number().min(0).max(10),
  attendance3rdSem: z.number().min(0).max(100),
  assignment3rdSem: z.number().min(0).max(100),
  sessional3rdSem: z.number().min(0).max(100),
  internal3rdSem: z.number().min(0).max(100),
  gender: z.string().min(1),
  department: z.string().min(1),
  studentId: z.number().int().positive().optional(),
});

type FeatureInput = z.infer<typeof featureSchema>;

function toPythonFeatures(input: FeatureInput) {
  return {
    "10th Marks in percent": input.tenthMarks,
    "Attendence of 10th": input.tenthAttendance,
    "12th Marks in percent": input.twelfthMarks,
    "Attendence of 12th": input.twelfthAttendance,
    "CGPA of 1st Sem": input.cgpa1stSem,
    "Attendence of 1st Sem": input.attendance1stSem,
    "Assignment Marks of 1st Sem": input.assignment1stSem,
    "Sessional Marks of 1st Sem": input.sessional1stSem,
    "Internal Marks of 1st Sem": input.internal1stSem,
    "CGPA of 2nd Sem": input.cgpa2ndSem,
    "Attendence of 2nd Sem": input.attendance2ndSem,
    "Assignment Marks of 2nd Sem": input.assignment2ndSem,
    "Sessional Marks of 2nd Sem": input.sessional2ndSem,
    "Internal Marks of 2rnd Sem": input.internal2ndSem,
    "CGPA of 3rd Sem": input.cgpa3rdSem,
    "Attendence of 3rd Sem": input.attendance3rdSem,
    "Assignment Marks of 3rd Sem": input.assignment3rdSem,
    "Sessional Marks of 3rd Sem": input.sessional3rdSem,
    "Internal Marks of 3rd Sem": input.internal3rdSem,
    Gender: input.gender,
    Department: input.department,
  };
}

function runPythonPrediction(features: Record<string, unknown>): Promise<number> {
  const script = path.resolve(process.cwd(), "server/predict.py");
  return new Promise((resolve, reject) => {
    const child = spawn("python3", [script], { cwd: path.dirname(script) });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", chunk => { stdout += chunk.toString(); });
    child.stderr.on("data", chunk => { stderr += chunk.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      if (code !== 0) {
        reject(new Error(stderr || `Prediction process exited with code ${code}`));
        return;
      }
      try {
        const parsed = JSON.parse(stdout.trim()) as { prediction?: number; error?: string };
        if (typeof parsed.prediction !== "number") throw new Error(parsed.error || "Model returned no prediction");
        resolve(parsed.prediction);
      } catch (error) {
        reject(error);
      }
    });
    child.stdin.write(JSON.stringify(features));
    child.stdin.end();
  });
}

export const predictionRouter = router({
  predict: publicProcedure.input(featureSchema).mutation(async ({ input }) => {
    const predictedCgpa = Math.min(10, Math.max(0, Number((await runPythonPrediction(toPythonFeatures(input))).toFixed(2))));
    const modelMetrics = JSON.parse(await readFile(path.resolve(process.cwd(), "server/model_metrics.json"), "utf8")) as { r2: number };
    const student = input.studentId ? await getStudentById(input.studentId) : undefined;

    if (input.studentId) {
      const db = await getDb();
      if (db && student) {
        await db.insert(predictions).values({
          studentId: input.studentId,
          predictedCgpa: predictedCgpa.toFixed(2),
          actualCgpa: String(student.cgpa4thSem),
          inputFeatures: JSON.stringify(input),
        });
      }
    }

    return {
      predictedCgpa,
      confidence: modelMetrics.r2,
      model: "Linear Regression · 21 features",
      actualCgpa: student ? Number(student.cgpa4thSem) : null,
      studentName: student?.studentName ?? null,
      generatedAt: new Date().toISOString(),
    };
  }),
});
