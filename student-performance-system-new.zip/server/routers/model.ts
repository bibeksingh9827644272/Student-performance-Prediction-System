import { readFile } from "node:fs/promises";
import path from "node:path";
import { publicProcedure, router } from "../_core/trpc";

type ModelMetrics = {
  algorithm: string;
  r2: number;
  mse: number;
  featureCount: number;
  trainingRows: number;
  testRows: number;
  features: Array<{ feature: string; value: number }>;
  comparison: Array<{ actual: number; predicted: number }>;
  seed: number;
};

export const modelRouter = router({
  getMetrics: publicProcedure.query(async (): Promise<ModelMetrics> => {
    const file = path.resolve(process.cwd(), "server/model_metrics.json");
    return JSON.parse(await readFile(file, "utf8")) as ModelMetrics;
  }),
});
