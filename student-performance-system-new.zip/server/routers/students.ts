import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import {
  getAllStudents,
  getStudentCount,
  searchStudents,
  getStudentByRollNo,
  getStudentById,
  getStudentsByDepartment,
  getStudentsByGender,
} from "../db";

const cgpa = (value: unknown) => Number(value ?? 0);

export const studentsRouter = router({
  all: publicProcedure.query(async () => getAllStudents(500, 0)),

  list: publicProcedure
    .input(z.object({ page: z.number().min(1).default(1), limit: z.number().min(1).max(100).default(20) }))
    .query(async ({ input }) => {
      const offset = (input.page - 1) * input.limit;
      const [students, total] = await Promise.all([getAllStudents(input.limit, offset), getStudentCount()]);
      const totalNumber = Number(total ?? 0);
      return { students, total: totalNumber, page: input.page, limit: input.limit, totalPages: Math.ceil(totalNumber / input.limit) };
    }),

  search: publicProcedure.input(z.object({ query: z.string().min(1) })).query(async ({ input }) => {
    const results = await searchStudents(input.query);
    return { results, count: results.length };
  }),

  getByRollNo: publicProcedure.input(z.object({ rollNo: z.string() })).query(async ({ input }) => {
    const student = await getStudentByRollNo(input.rollNo);
    if (!student) throw new Error("Student not found");
    return student;
  }),

  getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const student = await getStudentById(input.id);
    if (!student) throw new Error("Student not found");
    return student;
  }),

  getByDepartment: publicProcedure.input(z.object({ department: z.string() })).query(async ({ input }) => getStudentsByDepartment(input.department)),
  getByGender: publicProcedure.input(z.object({ gender: z.string() })).query(async ({ input }) => getStudentsByGender(input.gender)),

  getStats: publicProcedure.query(async () => {
    const total = await getStudentCount();
    const allStudents = await getAllStudents(500, 0);
    if (!allStudents.length) return { totalStudents: 0, avgCgpa: 0, departments: [], genders: [] };
    const avgCgpa = allStudents.reduce((sum, student) => sum + cgpa(student.cgpa4thSem), 0) / allStudents.length;
    const departments = Array.from(new Set(allStudents.map(student => student.department))).map(name => {
      const subset = allStudents.filter(student => student.department === name);
      return { name, count: subset.length, avgCgpa: Number((subset.reduce((sum, student) => sum + cgpa(student.cgpa4thSem), 0) / subset.length).toFixed(2)) };
    });
    const genders = Array.from(new Set(allStudents.map(student => student.gender))).map(name => ({ name, count: allStudents.filter(student => student.gender === name).length }));
    return { totalStudents: Number(total ?? allStudents.length), avgCgpa: Number(avgCgpa.toFixed(2)), departments, genders };
  }),

  getAnalytics: publicProcedure.query(async () => {
    const allStudents = await getAllStudents(500, 0);
    if (!allStudents.length) return { cgpaDistribution: [], departmentPerformance: [], attendanceVsCgpa: [], semesterTrends: [] };

    const cgpaDistribution = allStudents.map(student => ({ rollNo: student.rollNo, cgpa: cgpa(student.cgpa4thSem), department: student.department, batch: student.batch }));
    const departments = Array.from(new Set(allStudents.map(student => student.department)));
    const departmentPerformance = departments.map(department => {
      const subset = allStudents.filter(student => student.department === department);
      return { department, avgCgpa: Number((subset.reduce((sum, student) => sum + cgpa(student.cgpa4thSem), 0) / subset.length).toFixed(2)), count: subset.length };
    });
    const attendanceVsCgpa = allStudents.slice(0, 150).map(student => ({
      attendance: (student.attendance1stSem + student.attendance2ndSem + student.attendance3rdSem + student.attendance4thSem) / 4,
      cgpa: cgpa(student.cgpa4thSem),
      name: student.studentName,
    }));
    const semesterTrends = [
      { semester: "1st", avgCgpa: Number((allStudents.reduce((sum, student) => sum + cgpa(student.cgpa1stSem), 0) / allStudents.length).toFixed(2)) },
      { semester: "2nd", avgCgpa: Number((allStudents.reduce((sum, student) => sum + cgpa(student.cgpa2ndSem), 0) / allStudents.length).toFixed(2)) },
      { semester: "3rd", avgCgpa: Number((allStudents.reduce((sum, student) => sum + cgpa(student.cgpa3rdSem), 0) / allStudents.length).toFixed(2)) },
      { semester: "4th", avgCgpa: Number((allStudents.reduce((sum, student) => sum + cgpa(student.cgpa4thSem), 0) / allStudents.length).toFixed(2)) },
    ];
    return { cgpaDistribution, departmentPerformance, attendanceVsCgpa, semesterTrends };
  }),
});
