import { describe, expect, it } from "vitest";
import { spawn } from "node:child_process";
import path from "node:path";

const script = path.resolve(process.cwd(), "server/predict.py");
const features = {
  "10th Marks in percent": 78,
  "Attendence of 10th": 90,
  "12th Marks in percent": 82,
  "Attendence of 12th": 90,
  "CGPA of 1st Sem": 7.8,
  "Attendence of 1st Sem": 84,
  "Assignment Marks of 1st Sem": 76,
  "Sessional Marks of 1st Sem": 74,
  "Internal Marks of 1st Sem": 78,
  "CGPA of 2nd Sem": 8.1,
  "Attendence of 2nd Sem": 86,
  "Assignment Marks of 2nd Sem": 80,
  "Sessional Marks of 2nd Sem": 78,
  "Internal Marks of 2rnd Sem": 81,
  "CGPA of 3rd Sem": 8.4,
  "Attendence of 3rd Sem": 88,
  "Assignment Marks of 3rd Sem": 83,
  "Sessional Marks of 3rd Sem": 82,
  "Internal Marks of 3rd Sem": 84,
  Gender: "Female",
  Department: "Information Technology",
};

function runPrediction(input: Record<string, unknown>) {
  return new Promise<{ prediction: number }>((resolve, reject) => {
    const child = spawn("python3", [script], { cwd: path.dirname(script) });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", chunk => { stdout += chunk.toString(); });
    child.stderr.on("data", chunk => { stderr += chunk.toString(); });
    child.on("error", reject);
    child.on("close", code => code === 0 ? resolve(JSON.parse(stdout)) : reject(new Error(stderr)));
    child.stdin.end(JSON.stringify(input));
  });
}

describe("CGPA prediction model wrapper", () => {
  it("accepts all 21 features and returns a bounded numeric forecast", async () => {
    const result = await runPrediction(features);
    expect(result.prediction).toEqual(expect.any(Number));
    expect(result.prediction).toBeGreaterThanOrEqual(0);
    expect(result.prediction).toBeLessThanOrEqual(10);
  });

  it("rejects incomplete feature payloads", async () => {
    await expect(runPrediction({ ...features, Department: undefined })).rejects.toThrow(/Missing feature/);
  });
});
